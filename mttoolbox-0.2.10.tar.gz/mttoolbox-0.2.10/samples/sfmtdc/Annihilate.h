#pragma once
#ifndef ANNIHILATE_H
#define ANNIHILATE_H

#include "sfmtsearch.hpp"
bool anni(MTToolBox::sfmt& sf);

#endif // ANNIHILATE_H
