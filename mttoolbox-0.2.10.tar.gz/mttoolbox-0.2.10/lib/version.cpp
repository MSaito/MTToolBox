#include "config.h"
#include <MTToolBox/version.h>

namespace MTToolBox {
    const char * get_mttoolbox_version()
    {
        return VERSION;
    }
}
