#include <NTL/GF2X.h>
#include <stdio.h>

void printBinary(FILE *fp, const NTL::GF2X& poly);
