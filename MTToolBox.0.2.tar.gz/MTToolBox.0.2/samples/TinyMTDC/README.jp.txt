このサンプルは、公開済みの
TinyMTDC(http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/TINYMT/)と全く
同じ結果を出力するはずであるが、MTToolBoxの実装が異なるので、実行速度で
は公開済みのものに劣るはずである。
なお、公開済みのTinyMTDCで使用しているMTToolBox は速度に重点が置かれ、
こちらのMTToolBox は汎用性と使いやすさに重点が置かれているので、どちら
が優れているというものではない。
