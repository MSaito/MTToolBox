This sample is under developing.
Do not use This sample.

作りかけですが、他を優先するため中断しています。
使用しないように。
